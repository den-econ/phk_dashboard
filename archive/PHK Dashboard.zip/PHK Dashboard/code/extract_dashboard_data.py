"""
extract_dashboard_data.py
-------------------------
Reproducible extraction of the figures injected into the PHK Early Warning
Dashboard from the source workbook "Data untuk PHK Dashboard.xlsx".

This script documents the ONE new data series added in the June 2026 revision:
the provincial "Jumlah Penduduk Bekerja" (working population, 2025), which feeds
  - the new "Jumlah tenaga kerja" KPI on the Executive tab (national total), and
  - the per-province "Jumlah tenaga kerja (2025)" metric in the Peta Risiko detail panel,
  - the head-count weighting in the CGE Simulation tab.

Run:
    python extract_dashboard_data.py  /path/to/Data untuk PHK Dashboard.xlsx

Output: prints WORKFORCE_2025 (JS object) + WORKFORCE_NATIONAL, and writes
        workforce_2025.js next to this script.

Source sheet : "Database (Tahun)"
  col 0  = Provinsi
  col 1  = Tahun
  col 10 = Jumlah Penduduk Bekerja
We take the latest available year (2025) per province and sum across 38 provinces.
National total (2025) = 146,542,264 working population.
"""
import sys, json, os
import openpyxl

DEFAULT_XLSX = r"C:\Users\LENOVO\Documents\Data untuk PHK Dashboard.xlsx"

def extract(xlsx_path):
    wb = openpyxl.load_workbook(xlsx_path, data_only=True, read_only=True)
    ws = wb["Database (Tahun)"]
    by_prov = {}
    for row in ws.iter_rows(min_row=2, values_only=True):
        prov, yr, bekerja = row[0], row[1], row[10]
        if prov is None or yr is None:
            continue
        by_prov.setdefault(prov, {})[int(yr)] = bekerja
    latest = max(y for d in by_prov.values() for y in d)
    out = {}
    for prov, yd in by_prov.items():
        v = yd.get(latest)
        if v is None:  # fall back to most recent non-null year
            yrs = [k for k in yd if yd[k] is not None]
            if yrs:
                v = yd[max(yrs)]
        if v is not None:
            out[prov] = int(v)
    return latest, out

if __name__ == "__main__":
    path = sys.argv[1] if len(sys.argv) > 1 else DEFAULT_XLSX
    year, data = extract(path)
    total = sum(data.values())
    print(f"Latest year: {year}")
    print(f"National working population: {total:,}  (~{total/1e6:.1f} juta)")
    js = "const WORKFORCE_2025 = " + json.dumps(data, ensure_ascii=False) + ";\n"
    js += f"const WORKFORCE_NATIONAL = {total};\n"
    out_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "workforce_2025.js")
    with open(out_path, "w", encoding="utf-8") as f:
        f.write(js)
    print(f"Wrote {out_path}")
