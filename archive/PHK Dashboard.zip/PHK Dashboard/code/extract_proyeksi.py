"""
extract_proyeksi.py
-------------------
Builds the PROYEKSI dataset embedded in the dashboard's "Proyeksi Risiko PHK
Terkini" heatmap (in the Macro Sensitivity tab), from data_layoff.xlsx.

Source sheets:
  - "Proyeksi Risiko Terkini"  → Prediksi_Jumlah_PHK_Orang (fractional logit
       projection, 9 macro variables), Persentase_Risiko, Probabilitas_Layoff_Aktual,
       Jumlah_Penduduk_Bekerja  (Tahun_Data=2025, Bulan_Data=12)
  - "Kondisi Variabel Terkini" → the 9 macro variables per province:
       Delta_PMI, Growth_IHK, Growth_Ekspor, Growth_Impor, Growth_NPL,
       Growth_Kurs, Growth_Brent, Growth_IHPB, Delta_BI_Rate

Red/yellow/green labeling:
  The displayed number is the predicted layoff count. We winsorize that count at
  the 5th/95th percentile across the 33 provinces, min-max normalize to 0-100
  ("score"), then band:  score >= 50 -> high (red),  >= 20 -> med (yellow),
  else low (green). This mirrors the winsorized normalization used for the LPI
  components. (Dec 2025 data → 5 high / 7 med / 21 low.)

Run:  python extract_proyeksi.py [path/to/data_layoff.xlsx]
Writes proyeksi_data.js next to this script.
"""
import sys, json, math, os
import openpyxl

DEFAULT = r"C:\Users\LENOVO\Documents\PHK Dashboard\data_layoff.xlsx"

def pctl(p, arr):
    arr = sorted(arr); k = (len(arr)-1)*p; f = math.floor(k); c = math.ceil(k)
    return arr[f] if f == c else arr[f]*(c-k) + arr[c]*(k-f)

def sheet(wb, name):
    ws = wb[name]; rows = list(ws.iter_rows(values_only=True)); hdr = rows[0]
    return [dict(zip(hdr, r)) for r in rows[1:] if r[0] is not None]

def main(path):
    wb = openpyxl.load_workbook(path, data_only=True, read_only=True)
    proj = sheet(wb, "Proyeksi Risiko Terkini")
    kond = {d["Provinsi"]: d for d in sheet(wb, "Kondisi Variabel Terkini")}
    preds = [d["Prediksi_Jumlah_PHK_Orang"] for d in proj]
    lo, hi = pctl(0.05, preds), pctl(0.95, preds)
    score = lambda v: max(0, min(1, (v-lo)/(hi-lo)))*100 if hi > lo else 0
    band  = lambda s: "high" if s >= 50 else ("med" if s >= 20 else "low")
    out = {}
    for d in proj:
        p = d["Provinsi"]; k = kond.get(p, {}); s = round(score(d["Prediksi_Jumlah_PHK_Orang"]), 1)
        out[p] = {
            "pred": d["Prediksi_Jumlah_PHK_Orang"], "pct": d["Persentase_Risiko"],
            "prob": round(d["Probabilitas_Layoff_Aktual"], 6), "bekerja": d["Jumlah_Penduduk_Bekerja"],
            "score": s, "band": band(s),
            "vars": {"dPMI": k.get("Delta_PMI"), "gIHK": k.get("Growth_IHK"),
                "gEkspor": k.get("Growth_Ekspor"), "gImpor": k.get("Growth_Impor"),
                "gNPL": k.get("Growth_NPL"), "gKurs": k.get("Growth_Kurs"),
                "gBrent": k.get("Growth_Brent"), "gIHPB": k.get("Growth_IHPB"),
                "dBI": k.get("Delta_BI_Rate")},
        }
    js = "const PROYEKSI = " + json.dumps(out, ensure_ascii=False) + ";"
    dst = os.path.join(os.path.dirname(os.path.abspath(__file__)), "proyeksi_data.js")
    open(dst, "w", encoding="utf-8").write(js)
    bands = {b: sum(1 for v in out.values() if v["band"] == b) for b in ("high", "med", "low")}
    print(f"winsorize 5/95 pctl = ({lo:.1f}, {hi:.1f}); bands = {bands}; n = {len(out)}")
    print(f"wrote {dst}")

if __name__ == "__main__":
    main(sys.argv[1] if len(sys.argv) > 1 else DEFAULT)
