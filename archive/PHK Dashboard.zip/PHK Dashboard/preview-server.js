// Minimal static server for local preview/verification of the dashboard.
const http = require('http');
const fs = require('fs');
const path = require('path');

const ROOT = __dirname;
const DASH = 'PHK Early Warning Dashboard — Dewan Ekonomi.html';
const types = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.download': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.png': 'image/png',
  '': 'text/css; charset=utf-8', // css2 has no extension
};

http.createServer((req, res) => {
  let rel = decodeURIComponent(req.url.split('?')[0]);
  if (rel === '/' || rel === '') rel = '/' + DASH;
  const file = path.join(ROOT, rel);
  fs.readFile(file, (err, data) => {
    if (err) { res.writeHead(404); res.end('Not found: ' + rel); return; }
    res.writeHead(200, { 'Content-Type': types[path.extname(file)] || 'application/octet-stream' });
    res.end(data);
  });
}).listen(8099, () => console.log('preview server on http://localhost:8099'));
