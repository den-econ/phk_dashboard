# PHK Early Warning Dashboard — Dewan Ekonomi

Self-contained, single-file HTML dashboard (Chart.js, no backend) for monitoring
layoff (PHK) pressure across Indonesia's 38 provinces, built from
`Data untuk PHK Dashboard.xlsx`.

## Folder layout (reproducible)

```
PHK Dashboard/
├── PHK Early Warning Dashboard — Dewan Ekonomi.html   ← working copy (edited/previewed)
├── PHK Early Warning Dashboard — Dewan Ekonomi_files/ ← Chart.js + fonts (local)
├── outputs/                                           ← deliverable
│   ├── PHK Early Warning Dashboard — Dewan Ekonomi.html   (Kemnaker logo embedded as base64)
│   ├── PHK Early Warning Dashboard — Dewan Ekonomi_files/ (Chart.js + fonts)
│   └── assets/kemnaker-logo.png                           (logo source, for reference)
├── code/
│   ├── extract_dashboard_data.py   ← derives WORKFORCE_2025 from the workbook
│   ├── workforce_2025.js           ← generated: per-province + national working population
│   └── logo_datauri.txt            ← base64 data URI of the Kemnaker logo (embedded in HTML)
├── preview-server.js               ← tiny static server for local verification
└── .claude/launch.json             ← preview config (port 8099)
```

Open `outputs/PHK Early Warning Dashboard — Dewan Ekonomi.html` directly in a
browser, or run `node preview-server.js` and visit http://localhost:8099.

**The HTML is a fully self-contained single file** — safe to email/move on its own:
Chart.js is inlined, the Kemnaker logo is an embedded base64 data URI, and there are
**no references to any companion `_files` folder**. The only external dependency is
the Google Fonts CDN link (Inter / Plus Jakarta Sans); with no internet the dashboard
still works fully, just with system-font fallback. (Earlier, Chart.js was loaded from
a local relative path; emailing the HTML alone left it missing, which crashed the
script before tab handlers were attached — that's why tabs were unclickable. Now
fixed, plus a defensive guard so a missing chart library can never freeze navigation.)

## Proyeksi Risiko PHK Terkini (added to Macro Sensitivity)

A second province heatmap lives in the **Macro Sensitivity** tab, built from
`data_layoff.xlsx` (sheets "Proyeksi Risiko Terkini" + "Kondisi Variabel Terkini",
Dec 2025). Each province card shows the **predicted layoff count**
(`Prediksi_Jumlah_PHK_Orang`) from a **fractional logit model on 9 macro variables**,
not the LPI. Cards are coloured by a winsorized banding of that count (5th/95th
percentile → 0-100 → high≥50 / med≥20 / low). Clicking a province shows the 9
condition variables (Δ PMI, Growth IHK/Ekspor/Impor/NPL/Kurs/Brent/IHPB, Δ BI Rate)
plus predicted count, risk %, and working population. Reproduced by
`code/extract_proyeksi.py` (→ `proyeksi_data.js`). Covers 33 provinces (those present
in the projection data). Variable values are shown neutral — sign-colouring is
avoided because the "bad" direction differs per variable (export growth up lowers
risk, NPL growth up raises it).

## Latest tweaks (June 2026, second pass)

- **Header** — Kemnaker logo enlarged; credit line reads "Dikembangkan oleh Dewan
  Ekonomi Nasional Republik Indonesia"; "Dewan Ekonomi Nasional ·" dropped from the
  subtitle (now just "Sistem Pemantauan Tekanan Pasar Kerja").
- **Tab 06** renamed **Metodologi CGE** (to make clear it documents the CGE approach).
- **LPI Decomposition** (Peta Risiko) gained a "Tampilan" selector: *Top 12 provinsi*,
  *Rata-rata per pulau* (one bar per island), or drill into any island to see **all
  its provinces** — covering all 38. Island names are Indonesian (Sumatera, Jawa,
  Bali & Nusa Tenggara, Kalimantan, Sulawesi, Maluku, Papua).
- **National LPI is now a weighted average** — each province's LPI weighted by its
  formal-sector employment (`% pekerja formal × jumlah penduduk bekerja`). Result:
  **49,0** (vs 40,6 unweighted), reflecting that large formal-employment provinces
  (Jawa Barat, Jawa Tengah, DKI, Banten) carry the most weight. Tooltips updated to
  say "rata-rata tertimbang … dibobot dengan jumlah tenaga kerja formal".

## June 2026 revision — changes in this version

1. **Branding** — Kementerian Ketenagakerjaan (Kemnaker) logo in the top-left,
   with "Dibuat oleh Dewan Ekonomi Nasional" beneath it (replaces the shield mark).
2. **Executive KPIs** — removed "Struktur paling rentan"; added **Jumlah tenaga
   kerja** (146,5 juta, 2025) to the left of Total PHK tercatat YTD.
3. **Peta Risiko PHK** — the **LPI Decomposition** chart moved here from Advanced.
   The detail panel now shows the **value of whichever index is selected** in the
   sort dropdown (LPI / Kerentanan struktural / Tekanan ekonomi / Sinyal pasar kerja),
   not always LPI. Province cards no longer show the flow ▲/▼ arrows. Added a
   "Jumlah tenaga kerja (2025)" row to the detail metrics.
4. **Macro Sensitivity** (renamed from Driver Analysis) — now also hosts the
   **Leading Indicator Analysis** heatmap (moved from Advanced).
5. **Provincial Cluster & Sectoral Risk** (renamed from Advanced Analysis) — keeps
   the cluster cards and the sectoral risk module.
6. **CGE Simulation** (replaces Shock Simulator) — a linearized-CGE sector × province
   employment-change matrix `E[i,r] = Σ_j η[i,r,j] · x_j`, driven by shock-magnitude
   sliders, rendered as a heatmap with an auto-narrative. **Elasticities (η) and
   employment shares (s) are placeholders** pending IndoTERM calibration.
7. **Methodology** (replaces Policy Response) — a visual explainer of
   `layoff_dashboard_methodology.pdf`: the 3-step offline-calibration / live-shock /
   real-time-aggregation pipeline, the equations, the computational split, the five
   known limitations, and the upgrade path.

## Data provenance

All headline figures derive from `Data untuk PHK Dashboard.xlsx`. The only new
series added in this revision is the provincial working population
(`Jumlah Penduduk Bekerja`, sheet "Database (Tahun)", 2025), reproduced via
`code/extract_dashboard_data.py` → national total **146,542,264**.

The LPI methodology (normalized weighted composite: 30% struktural, 30% tekanan
ekonomi, 25% pasar kerja, 15% eksternal) and the CGE placeholder values are
described in the dashboard's Methodology tab and in
`layoff_dashboard_methodology.pdf`.
